ASSIGNMENT 8 - HTML & CSS

Contains:
1. solution1.html + solution1.css - Pseudo-Classes
2. solution2.html + solution2.css - Tooltips
3. solution3.html + solution3.css - Image Showcase
4. solution4.html + solution4.css - CSS Selectors
5. solution5.html + solution5.css - Button Collection
6. solution6.html + solution6.css - CSS Animations
7. solution7.html + solution7.css - UI Components
8. solution8.html + solution8.css - Box-Sizing Comparison
9. solution9.html + solution9.css - Combined Effects
10. solution10.html + solution10.css - Mini User Interface

Open any HTML file in a browser. No JavaScript or CSS frameworks are used.
